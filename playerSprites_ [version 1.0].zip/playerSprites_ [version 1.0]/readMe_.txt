
thank you for using the playerSprites_...part of the fantasy_ series' of assets on itch.io!


stuff to know - character and weapon animations

- each frame is 32x32 pixels

- character animations [from top to bottom]
  - spawn, idle, run, jump [idle], jump [run], land, roll, turn, hit and death

- weapon animations [from top to bottom]
  - sword_ [wood, iron, gold and diamond]
    - idle, swing and stab
  - shield_ [wood, iron, gold and diamond]
    - idle, bash & hit

stuff to know - dust animations

- each frame is 48x48 pixels
- each dust animation is designed to be played at the character's position [x = 0 & y = 0 relative to the player]

- dust animations [from top to bottom]
 - run, land, roll, hit and death



future updates - 

- upward-facing animations 
- spin animation
- more dagger and axe animations [magic!]

...if you have any questions or requests you can contact me at analogstudios.inc@gmail.com





                                                             